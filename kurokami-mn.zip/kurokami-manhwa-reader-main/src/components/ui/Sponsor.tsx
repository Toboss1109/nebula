// @ts-nocheck
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCertificate, faHandshake } from "@fortawesome/free-solid-svg-icons";
// 480px WebP derived from the 869KB source PNG — same mark, ~57KB.
import ambaBrand from "../../assets/images/logos/amba_brand.webp";

/**
 * Official sponsor block — sits at the very bottom of the home page, directly
 * above the footer. Single highlighted partner, so the layout centres on the
 * brand mark rather than a logo wall.
 */
const Sponsor = () => (
  <section aria-labelledby="sponsor-heading" className="w-full">
    <div className="flex items-center gap-2.5 lg:gap-3 mb-3 lg:mb-4">
      <span className="w-1 lg:w-1.5 h-5 lg:h-7 bg-[#EF4444] rounded-full flex-shrink-0" />
      <FontAwesomeIcon icon={faHandshake} className="text-[#EF4444] text-sm lg:text-lg" />
      <h2 id="sponsor-heading" className="font-black text-sm sm:text-base lg:text-xl tracking-tight">
        Official Sponsor
      </h2>
    </div>

    <div className="relative overflow-hidden rounded-2xl lg:rounded-3xl border border-[#EF4444]/25 bg-[#141417]">
      {/* warm glow behind the brand mark */}
      <div className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-[#EF4444]/12 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#EF4444] to-transparent" />

      <div className="relative flex flex-col sm:flex-row items-center gap-5 sm:gap-7 lg:gap-10 p-5 sm:p-7 lg:p-10">
        {/* brand mark */}
        <div className="flex-shrink-0 flex items-center justify-center rounded-2xl bg-white/[0.04] border border-white/10 p-3 sm:p-4">
          <img
            src={ambaBrand.src}
            alt="AmbaStore — Kurokami-ийн албан ёсны ивээн тэтгэгч"
            loading="lazy"
            decoding="async"
            width={480}
            height={400}
            className="w-28 sm:w-36 md:w-40 lg:w-52 h-auto object-contain"
          />
        </div>

        {/* copy */}
        <div className="flex-1 min-w-0 flex flex-col items-center sm:items-start gap-2 text-center sm:text-left">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 lg:px-3.5 lg:py-1.5 rounded-full bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] text-[10px] lg:text-xs font-black uppercase tracking-widest">
            <FontAwesomeIcon icon={faCertificate} className="text-[9px]" />
            Албан ёсны ивээн тэтгэгч
          </span>

          <h3 className="text-lg sm:text-xl lg:text-3xl font-black tracking-tight text-white break-words">
            AmbaStore
          </h3>

          <p className="text-zinc-400 text-xs sm:text-sm lg:text-base leading-relaxed max-w-md lg:max-w-xl">
            Kurokami-г <span className="text-white font-semibold">AmbaStore</span> албан ёсны ивээн
            тэтгэгчээр бүрэн дэмжиж байна.
            </p>

          <p className="text-zinc-600 text-[11px] lg:text-sm mt-0.5 lg:mt-1">
            Дараагийн ивээн тэтгэгч болмоор байна уу?{" "}
            <a href="/info" className="text-[#EF4444] font-semibold hover:underline">
              Бидэнтэй холбогдох
            </a>
          </p>
        </div>
      </div>
    </div>
  </section>
);

export default Sponsor;
