import { supabase } from "./supabase";

/**
 * Хадгалсан / унших түүх / уншсан бүлгийг бүртгэлтэй синхрончлоно.
 *
 * Сайтын бусад код localStorage-ийг шууд ашигладаг тул тэдгээрийг өөрчлөхгүйгээр
 * localStorage.setItem/removeItem-ийг "kurokami_" түлхүүрүүд дээр чагнаж,
 * өөрчлөлт гарахад Supabase руу (`user_data` хүснэгт) түр хойшлуулан илгээнэ.
 */

const PREFIX = "kurokami_";
const LAST_READ_PREFIX = "kurokami_last_read_";
const META_KEY = "ksync_meta"; // { uid, dirty }
const PUSH_DELAY = 1500;

type Snapshot = {
  bookmarks: string[];
  history: Record<string, any>;
  read_chapters: Record<string, number>;
  last_read: Record<string, string>;
};

type Meta = { uid: string | null; dirty: boolean };

const isBrowser = typeof window !== "undefined";
const rawSet = isBrowser ? Storage.prototype.setItem : null;
const rawRemove = isBrowser ? Storage.prototype.removeItem : null;

// ── localStorage helpers (patch-ийг тойрсон) ──
const lsSet = (k: string, v: string) => rawSet!.call(localStorage, k, v);
const lsRemove = (k: string) => rawRemove!.call(localStorage, k);

function parse<T>(key: string, fallback: T): T {
  try {
    const v = JSON.parse(localStorage.getItem(key) || "");
    return v ?? fallback;
  } catch {
    return fallback;
  }
}

function getMeta(): Meta {
  return parse<Meta>(META_KEY, { uid: null, dirty: false });
}
function setMeta(m: Meta) {
  try {
    lsSet(META_KEY, JSON.stringify(m));
  } catch {
    /* localStorage боломжгүй */
  }
}

function readLocal(): Snapshot {
  const last_read: Record<string, string> = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(LAST_READ_PREFIX)) {
      const v = localStorage.getItem(k);
      if (v) last_read[k.slice(LAST_READ_PREFIX.length)] = v;
    }
  }
  const bm = parse<any>("kurokami_bookmarks", []);
  return {
    bookmarks: Array.isArray(bm) ? bm : [],
    history: parse("kurokami_history", {}),
    read_chapters: parse("kurokami_read_chapters", {}),
    last_read,
  };
}

function writeLocal(s: Snapshot) {
  lsSet("kurokami_bookmarks", JSON.stringify(s.bookmarks));
  lsSet("kurokami_history", JSON.stringify(s.history));
  lsSet("kurokami_read_chapters", JSON.stringify(s.read_chapters));
  const keep = new Set(Object.keys(s.last_read));
  const stale: string[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(LAST_READ_PREFIX) && !keep.has(k.slice(LAST_READ_PREFIX.length))) stale.push(k);
  }
  stale.forEach(lsRemove);
  for (const [id, cid] of Object.entries(s.last_read)) lsSet(LAST_READ_PREFIX + id, cid);
}

function canon(v: any): string {
  if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
  if (v && typeof v === "object")
    return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + canon(v[k])).join(",") + "}";
  return JSON.stringify(v);
}

function merge(a: Snapshot, b: Snapshot): Snapshot {
  const bookmarks = [...a.bookmarks];
  for (const id of b.bookmarks) if (!bookmarks.includes(id)) bookmarks.push(id);

  const history: Record<string, any> = { ...a.history };
  for (const [id, h] of Object.entries(b.history)) {
    if (!history[id] || (h?.ts || 0) > (history[id]?.ts || 0)) history[id] = h;
  }

  const read_chapters: Record<string, number> = { ...a.read_chapters };
  for (const [cid, ts] of Object.entries(b.read_chapters)) {
    read_chapters[cid] = Math.max(read_chapters[cid] || 0, ts || 0);
  }

  const last_read: Record<string, string> = { ...a.last_read };
  for (const [id, cid] of Object.entries(b.last_read)) {
    if (!last_read[id] || (read_chapters[cid] || 0) > (read_chapters[last_read[id]] || 0)) last_read[id] = cid;
  }
  return { bookmarks, history, read_chapters, last_read };
}

// ── remote ──
async function fetchRemote(uid: string): Promise<{ error: boolean; snap: Snapshot | null }> {
  const { data, error } = await supabase!.from("user_data").select("*").eq("user_id", uid).maybeSingle();
  if (error) return { error: true, snap: null };
  if (!data) return { error: false, snap: null };
  return {
    error: false,
    snap: {
      bookmarks: Array.isArray(data.bookmarks) ? data.bookmarks : [],
      history: data.history ?? {},
      read_chapters: data.read_chapters ?? {},
      last_read: data.last_read ?? {},
    },
  };
}

async function pushSnapshot(uid: string, s: Snapshot): Promise<boolean> {
  const { error } = await supabase!.from("user_data").upsert(
    { user_id: uid, ...s, updated_at: new Date().toISOString() },
    { onConflict: "user_id" }
  );
  return !error;
}

// ── change tracking ──
let changeSeq = 0;
let pushTimer: ReturnType<typeof setTimeout> | null = null;
let activeUid: string | null = null;
let syncedUid: string | null = null;

async function pushNow() {
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
  }
  if (!activeUid || !supabase) return true;
  const seq = changeSeq;
  const ok = await pushSnapshot(activeUid, readLocal());
  if (ok && seq === changeSeq) setMeta({ uid: activeUid, dirty: false });
  return ok;
}

function onLocalChange() {
  changeSeq++;
  const m = getMeta();
  if (!m.dirty) setMeta({ uid: m.uid, dirty: true });
  if (!activeUid) return;
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(pushNow, PUSH_DELAY);
}

function installPatch() {
  const w = window as any;
  if (w.__kurokamiSyncPatched) return;
  w.__kurokamiSyncPatched = true;
  const track = (k: string) => k.startsWith(PREFIX);
  Storage.prototype.setItem = function (k: string, v: string) {
    rawSet!.call(this, k, v);
    if (this === window.localStorage && track(k)) onLocalChange();
  };
  Storage.prototype.removeItem = function (k: string) {
    rawRemove!.call(this, k);
    if (this === window.localStorage && track(k)) onLocalChange();
  };
}

async function syncOnce(uid: string) {
  activeUid = uid;
  if (syncedUid === uid) return;
  syncedUid = uid;

  const meta = getMeta();
  const local = readLocal();
  const { error, snap: remote } = await fetchRemote(uid);
  if (error) {
    syncedUid = null; // дараагийн боломжид дахин оролдоно
    return;
  }

  let final: Snapshot;
  let needPush = false;
  if (!remote) {
    final = local;
    needPush = true;
  } else if (meta.uid !== uid || meta.dirty) {
    // шинэ төхөөрөмж эсвэл push хийгдээгүй өөрчлөлттэй — нэгтгэнэ
    final = merge(local, remote);
    needPush = canon(final) !== canon(remote);
  } else {
    final = remote; // үнэний эх сурвалж нь бүртгэл (өөр төхөөрөмж дээр устгасан зүйл ч тусна)
  }

  const changed = canon(final) !== canon(local);
  if (changed) writeLocal(final);
  setMeta({ uid, dirty: needPush });
  if (needPush) await pushNow();

  if (changed && !location.pathname.startsWith("/chapter/")) location.reload();
}

/** Layout-аас бүх хуудсанд нэг удаа дуудагдана. */
export function initSync() {
  if (!isBrowser) return;
  installPatch();
  if (!supabase) return;

  supabase.auth.onAuthStateChange((event, session) => {
    // Анхаар: callback дотор supabase-ийн async дуудлагыг шууд хийж болохгүй.
    setTimeout(() => {
      if (session?.user && (event === "INITIAL_SESSION" || event === "SIGNED_IN" || event === "TOKEN_REFRESHED")) {
        syncOnce(session.user.id);
      } else if (event === "SIGNED_OUT") {
        activeUid = null;
        syncedUid = null;
      }
    }, 0);
  });

  const flush = () => {
    if (pushTimer) pushNow();
  };
  document.addEventListener("visibilitychange", () => document.visibilityState === "hidden" && flush());
  window.addEventListener("pagehide", flush);
}

/** Гарах: хүлээгдэж буй өөрчлөлтийг илгээж, session-г цуцалж, локал өгөгдлийг цэвэрлэнэ. */
export async function signOutAndClear() {
  if (!supabase) return;
  let flushed = true;
  if (activeUid && (pushTimer || getMeta().dirty)) flushed = await pushNow();
  await supabase.auth.signOut();
  activeUid = null;
  syncedUid = null;
  if (flushed) {
    const keys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX) || k === META_KEY)) keys.push(k);
    }
    keys.forEach(lsRemove);
  }
  location.href = "/";
}
