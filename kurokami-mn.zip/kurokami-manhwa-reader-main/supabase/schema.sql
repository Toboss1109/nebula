-- Kurokami: хэрэглэгчийн өгөгдөл (хадгалсан, унших түүх, уншсан бүлэг) синхрончлох хүснэгт.
-- Supabase Dashboard → SQL Editor дээр нэг удаа ажиллуулна.

create table if not exists public.user_data (
  user_id       uuid primary key references auth.users (id) on delete cascade,
  bookmarks     jsonb not null default '[]'::jsonb,
  history       jsonb not null default '{}'::jsonb,
  read_chapters jsonb not null default '{}'::jsonb,
  last_read     jsonb not null default '{}'::jsonb,
  updated_at    timestamptz not null default now()
);

-- Row Level Security: хэрэглэгч зөвхөн өөрийн мөрийг харна/засна.
alter table public.user_data enable row level security;

drop policy if exists "user_data_select_own" on public.user_data;
drop policy if exists "user_data_insert_own" on public.user_data;
drop policy if exists "user_data_update_own" on public.user_data;
drop policy if exists "user_data_delete_own" on public.user_data;

create policy "user_data_select_own" on public.user_data
  for select using (auth.uid() = user_id);
create policy "user_data_insert_own" on public.user_data
  for insert with check (auth.uid() = user_id);
create policy "user_data_update_own" on public.user_data
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "user_data_delete_own" on public.user_data
  for delete using (auth.uid() = user_id);
