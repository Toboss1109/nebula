// @ts-nocheck
import { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faLock,
  faEye,
  faEyeSlash,
  faSpinner,
  faTriangleExclamation,
  faCircleCheck,
} from "@fortawesome/free-solid-svg-icons";
import Navbar from "../components/common/Navbar";
import Footer from "../components/common/Footer";
import BottomNav from "../components/common/BottomNav";
import { supabase, authEnabled } from "../utils/supabase";

const COPY = {
  login: {
    title: "Нэвтрэх",
    subtitle: "Хадгалсан жагсаалт, унших түүхээ бүх төхөөрөмж дээрээ ашигла.",
    submit: "Нэвтрэх",
  },
  register: {
    title: "Бүртгүүлэх",
    subtitle: "Үнэгүй бүртгэл үүсгээд хадгалсан зүйлсээ алдалгүй хадгал.",
    submit: "Бүртгүүлэх",
  },
  forgot: {
    title: "Нууц үг сэргээх",
    subtitle: "Бүртгэлтэй имэйлээ оруулна уу. Сэргээх холбоос илгээнэ.",
    submit: "Холбоос илгээх",
  },
  reset: {
    title: "Шинэ нууц үг",
    subtitle: "Шинэ нууц үгээ оруулна уу.",
    submit: "Нууц үг солих",
  },
};

/** Supabase-ийн англи алдааг ойлгомжтой монгол мессеж болгоно. */
const explain = (err) => {
  const m = (err?.message || "").toLowerCase();
  if (m.includes("invalid login")) return "Имэйл эсвэл нууц үг буруу байна.";
  if (m.includes("already registered") || m.includes("already been registered")) return "Энэ имэйл аль хэдийн бүртгэлтэй байна.";
  if (m.includes("email not confirmed")) return "Имэйл хаягаа баталгаажуулаагүй байна. Ирсэн имэйлээ шалгана уу.";
  if (m.includes("at least") && m.includes("character")) return "Нууц үг хамгийн багадаа 6 тэмдэгттэй байх ёстой.";
  if (m.includes("same as the old") || m.includes("different from the old")) return "Шинэ нууц үг хуучнаасаа өөр байх ёстой.";
  if (m.includes("rate limit") || m.includes("too many") || m.includes("security purposes"))
    return "Хэт олон удаа оролдлоо. Түр хүлээгээд дахин оролдоно уу.";
  if (m.includes("failed to fetch") || m.includes("network")) return "Сүлжээний алдаа. Интернэт холболтоо шалгана уу.";
  if (m.includes("invalid email") || m.includes("unable to validate email")) return "Имэйл хаяг буруу байна.";
  return "Алдаа гарлаа. Дахин оролдоно уу.";
};

const safeNext = () => {
  const n = new URLSearchParams(window.location.search).get("next") || "/";
  return n.startsWith("/") && !n.startsWith("//") ? n : "/";
};

const Field = ({ icon, type = "text", value, onChange, placeholder, autoComplete, right }) => (
  <div className="relative">
    <FontAwesomeIcon icon={icon} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs pointer-events-none" />
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      autoComplete={autoComplete}
      required
      className="w-full pl-10 pr-11 py-3 bg-[#09090b] border border-zinc-800 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-[#EF4444]/60 transition-colors"
    />
    {right}
  </div>
);

const Auth = ({ mode = "login" }) => {
  const copy = COPY[mode];
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [recoveryReady, setRecoveryReady] = useState(mode !== "reset");
  const [checking, setChecking] = useState(mode === "reset");

  // Нэвтэрсэн хүн login/register руу орвол буцаана. reset дээр recovery session хүлээнэ.
  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return;
      if (data.session && (mode === "login" || mode === "register")) window.location.replace(safeNext());
      if (mode === "reset") {
        setRecoveryReady(Boolean(data.session));
        setChecking(false);
      }
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (mode === "reset" && (event === "PASSWORD_RECOVERY" || session)) {
        setRecoveryReady(true);
        setChecking(false);
      }
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [mode]);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setNotice("");
    if (!supabase) return;

    if ((mode === "register" || mode === "reset") && password.length < 6) {
      setError("Нууц үг хамгийн багадаа 6 тэмдэгттэй байх ёстой.");
      return;
    }
    if ((mode === "register" || mode === "reset") && password !== confirm) {
      setError("Нууц үг таарахгүй байна.");
      return;
    }

    setBusy(true);
    try {
      if (mode === "login") {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
        window.location.href = safeNext();
        return;
      }
      if (mode === "register") {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { emailRedirectTo: `${window.location.origin}/login` },
        });
        if (err) throw err;
        // Имэйл давхардвал Supabase аюулгүй байдлын үүднээс алдаа өгөхгүй, identities хоосон ирдэг.
        if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          setError("Энэ имэйл аль хэдийн бүртгэлтэй байна.");
        } else if (data.session) {
          window.location.href = safeNext();
          return;
        } else {
          setNotice("Бүртгэл үүслээ! Имэйлээ шалгаад баталгаажуулах холбоос дээр дарна уу.");
        }
      }
      if (mode === "forgot") {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) throw err;
        setNotice("Хэрэв энэ имэйл бүртгэлтэй бол нууц үг сэргээх холбоос илгээгдлээ. Имэйлээ шалгана уу.");
      }
      if (mode === "reset") {
        const { error: err } = await supabase.auth.updateUser({ password });
        if (err) throw err;
        setNotice("Нууц үг амжилттай солигдлоо. Түр хүлээнэ үү…");
        setTimeout(() => (window.location.href = "/"), 1200);
      }
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  };

  const eye = (
    <button
      type="button"
      onClick={() => setShow((s) => !s)}
      aria-label={show ? "Нууц үг нуух" : "Нууц үг харуулах"}
      className="absolute right-1.5 top-1/2 -translate-y-1/2 w-9 h-9 flex items-center justify-center text-zinc-500 hover:text-white hover:cursor-pointer"
    >
      <FontAwesomeIcon icon={show ? faEyeSlash : faEye} className="text-xs" />
    </button>
  );

  const showPassword = mode !== "forgot";
  const showConfirm = mode === "register" || mode === "reset";
  const showEmail = mode !== "reset";

  return (
    <div className="bg-[#09090b] text-white min-h-screen flex flex-col pb-[58px] lg:pb-0">
      <Navbar />
      <main className="flex-1 w-full flex items-start sm:items-center justify-center px-4 py-8 lg:py-14">
        <div className="w-full max-w-md bg-[#141417] border border-zinc-800/60 rounded-2xl p-5 sm:p-7 lg:p-9 shadow-2xl shadow-black/40">
          <div className="flex items-center gap-3 mb-1.5">
            <span className="w-1 h-7 bg-[#EF4444] rounded-full" />
            <h1 className="text-xl lg:text-2xl font-black tracking-tight">{copy.title}</h1>
          </div>
          <p className="text-zinc-500 text-xs lg:text-sm mb-6 leading-relaxed">{copy.subtitle}</p>

          {!authEnabled && (
            <div className="flex gap-2.5 p-3.5 mb-5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs leading-relaxed">
              <FontAwesomeIcon icon={faTriangleExclamation} className="mt-0.5 flex-shrink-0" />
              <span>
                Нэвтрэх систем тохируулагдаагүй байна. <code>.env</code> файлд <code>PUBLIC_SUPABASE_URL</code> болон{" "}
                <code>PUBLIC_SUPABASE_ANON_KEY</code>-г оруулна уу.
              </span>
            </div>
          )}

          {checking ? (
            <div className="flex items-center justify-center gap-2 py-10 text-zinc-500 text-sm">
              <FontAwesomeIcon icon={faSpinner} className="animate-spin" /> Шалгаж байна…
            </div>
          ) : mode === "reset" && !recoveryReady ? (
            <div className="text-sm text-zinc-400 leading-relaxed">
              Сэргээх холбоос хүчингүй эсвэл хугацаа нь дууссан байна.{" "}
              <a href="/forgot-password" className="text-[#EF4444] font-semibold hover:underline">
                Шинэ холбоос авах →
              </a>
            </div>
          ) : (
            <form onSubmit={submit} className="flex flex-col gap-3.5" noValidate={false}>
              {showEmail && (
                <Field icon={faEnvelope} type="email" value={email} onChange={setEmail} placeholder="Имэйл хаяг" autoComplete="email" />
              )}
              {showPassword && (
                <Field
                  icon={faLock}
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={setPassword}
                  placeholder={mode === "reset" ? "Шинэ нууц үг" : "Нууц үг"}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  right={eye}
                />
              )}
              {showConfirm && (
                <Field
                  icon={faLock}
                  type={show ? "text" : "password"}
                  value={confirm}
                  onChange={setConfirm}
                  placeholder="Нууц үгийг давтах"
                  autoComplete="new-password"
                />
              )}

              {mode === "login" && (
                <a href="/forgot-password" className="self-end text-xs text-zinc-500 hover:text-[#EF4444] transition-colors -mt-1">
                  Нууц үгээ мартсан уу?
                </a>
              )}

              {error && (
                <div role="alert" className="flex gap-2.5 p-3 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#F87171] text-xs leading-relaxed">
                  <FontAwesomeIcon icon={faTriangleExclamation} className="mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              {notice && (
                <div role="status" className="flex gap-2.5 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs leading-relaxed">
                  <FontAwesomeIcon icon={faCircleCheck} className="mt-0.5 flex-shrink-0" />
                  <span>{notice}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={busy || !authEnabled}
                className="mt-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] active:scale-[0.98] text-white text-sm font-black transition-all disabled:opacity-50 disabled:pointer-events-none hover:cursor-pointer"
              >
                {busy && <FontAwesomeIcon icon={faSpinner} className="animate-spin" />}
                {copy.submit}
              </button>
            </form>
          )}

          <div className="mt-6 pt-5 border-t border-zinc-800/70 text-center text-xs lg:text-sm text-zinc-500">
            {mode === "login" && (
              <>
                Бүртгэлгүй юу?{" "}
                <a href={`/register${window.location.search}`} className="text-[#EF4444] font-semibold hover:underline">
                  Бүртгүүлэх
                </a>
              </>
            )}
            {mode === "register" && (
              <>
                Бүртгэлтэй юу?{" "}
                <a href={`/login${window.location.search}`} className="text-[#EF4444] font-semibold hover:underline">
                  Нэвтрэх
                </a>
              </>
            )}
            {(mode === "forgot" || mode === "reset") && (
              <a href="/login" className="text-[#EF4444] font-semibold hover:underline">
                ← Нэвтрэх хуудас руу буцах
              </a>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <BottomNav />
    </div>
  );
};

export default Auth;
