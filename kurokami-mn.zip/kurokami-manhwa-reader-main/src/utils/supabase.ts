import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = import.meta.env.PUBLIC_SUPABASE_URL as string | undefined;
const key = import.meta.env.PUBLIC_SUPABASE_ANON_KEY as string | undefined;

/** false бол .env дотор Supabase-ийн түлхүүрүүд тохируулагдаагүй — нэвтрэх хэсэг идэвхгүй. */
export const authEnabled = Boolean(url && key);

/**
 * Зөвхөн хөтөч дээр үүснэ (SSR үед null). Session нь localStorage-д хадгалагдана.
 */
export const supabase: SupabaseClient | null =
  authEnabled && typeof window !== "undefined"
    ? createClient(url as string, key as string, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      })
    : null;
