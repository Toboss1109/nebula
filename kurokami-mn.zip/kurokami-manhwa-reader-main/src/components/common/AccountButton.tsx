// @ts-nocheck
import { useEffect, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faRightToBracket,
  faRightFromBracket,
  faBookmark,
  faClockRotateLeft,
} from "@fortawesome/free-solid-svg-icons";
import { supabase } from "../../utils/supabase";
import { signOutAndClear } from "../../utils/sync";

/**
 * Толгой хэсгийн бүртгэлийн товч.
 * - undefined: session шалгаж байна (байрлал үсрэхгүйн тулд хоосон хүрээ)
 * - null: нэвтрээгүй → "Нэвтрэх" холбоос
 * - user: нэвтэрсэн → цэс (хадгалсан, түүх, гарах)
 */
const AccountButton = () => {
  const [user, setUser] = useState(undefined);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [next, setNext] = useState("/");
  const ref = useRef(null);

  useEffect(() => {
    setNext(window.location.pathname + window.location.search);
    if (!supabase) {
      setUser(null);
      return;
    }
    let alive = true;
    supabase.auth.getSession().then(({ data }) => alive && setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (alive) setUser(session?.user ?? null);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    const onDown = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  if (user === undefined) return <span className="w-10 h-10 lg:w-11 lg:h-11 flex-shrink-0" aria-hidden="true" />;

  if (!user) {
    const skipNext = next.startsWith("/login") || next.startsWith("/register") || next.startsWith("/forgot") || next.startsWith("/reset");
    const href = skipNext || next === "/" ? "/login" : `/login?next=${encodeURIComponent(next)}`;
    return (
      <a
        href={href}
        aria-label="Нэвтрэх"
        title="Нэвтрэх"
        className="flex items-center justify-center gap-2 w-10 h-10 lg:w-auto lg:h-11 lg:px-4 rounded-xl bg-white/[0.04] lg:bg-[#EF4444] border border-zinc-800 lg:border-[#EF4444] text-zinc-300 lg:text-white lg:font-bold text-sm active:scale-95 lg:hover:bg-[#DC2626] transition-all"
      >
        <FontAwesomeIcon icon={faRightToBracket} className="text-sm" />
        <span className="hidden lg:inline">Нэвтрэх</span>
      </a>
    );
  }

  const email = user.email || "";
  const initial = (email[0] || "?").toUpperCase();

  const logout = async () => {
    setBusy(true);
    await signOutAndClear();
  };

  return (
    <div ref={ref} className="relative flex-shrink-0">
      <button
        onClick={() => setOpen((p) => !p)}
        aria-label="Миний бүртгэл"
        aria-expanded={open}
        className="w-10 h-10 lg:w-11 lg:h-11 flex items-center justify-center rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444] font-black text-sm hover:bg-[#EF4444]/25 active:scale-95 transition-all hover:cursor-pointer"
      >
        {initial}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-[#141417] border border-zinc-800 rounded-2xl shadow-2xl shadow-black/60 overflow-hidden z-[80]">
          <div className="px-4 py-3.5 border-b border-zinc-800/70">
            <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Нэвтэрсэн</p>
            <p className="text-sm text-white font-semibold truncate mt-0.5" title={email}>
              <FontAwesomeIcon icon={faUser} className="text-[#EF4444] text-xs mr-2" />
              {email}
            </p>
          </div>
          <a href="/bookmark" className="flex items-center gap-3 px-4 py-3 text-sm text-zinc-300 hover:bg-white/5 hover:text-white transition-colors">
            <FontAwesomeIcon icon={faBookmark} className="text-xs w-4" /> Хадгалсан
          </a>
          <a href="/history" className="flex items-center gap-3 px-4 py-3 text-sm text-zinc-300 hover:bg-white/5 hover:text-white transition-colors">
            <FontAwesomeIcon icon={faClockRotateLeft} className="text-xs w-4" /> Унших түүх
          </a>
          <button
            onClick={logout}
            disabled={busy}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-[#EF4444] hover:bg-[#EF4444]/10 border-t border-zinc-800/70 transition-colors disabled:opacity-50 hover:cursor-pointer text-left"
          >
            <FontAwesomeIcon icon={faRightFromBracket} className="text-xs w-4" />
            {busy ? "Гарч байна…" : "Гарах"}
          </button>
        </div>
      )}
    </div>
  );
};

export default AccountButton;
